<style>
    body{
        background-image: url("../images/image2.jpg");
        background-color: #cccccc;
       }
    </style>  
	<div>
		<form >
 			<fieldset style="  width: 100% ;height:100%">
 				<legend>Contact Information </legend>
 					<table >
 						<h1>Contact Us: </h1>
 						<tr>
 							<td>Address : </td>
 							<td>:</td>
 							<td>House 254, Road 9, Block C, Bashundhara R/A</td>
 						</tr>
 						<tr>
 							<td>Phone : </td>
 							<td>:</td>
 							<td>01717567435 </td>
 						</tr>
 						 	<tr>
 							<td></td>
 							<td></td>
 							<td>01616099200 </td>
 						</tr>

 						<tr>
 							<td>Email : </td>
 							<td>:</td>
 							<td>diprajdipto35@gmail.com</td>
 						</tr>
 							<tr>
 							<td></td>
 							<td></td>
                             
 									
 					</table>
                     <div>
        <a href="../controller/Homepage.php">Go Back to Home Page</a>
        </div>	
 			</fieldset>
 		</form>	
	</div>
    <?php
	include('footer.php');
?>
