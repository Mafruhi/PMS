<footer>
  <hr>
    <p><b>Pharmacy Management System Made By<a href="https://github.com/roydipto/WEB-TECHNOLOGIES"> Dipto</a></p></b>
   
  </footer>